#include<stdio.h>
void main()
{
    int a,b,substraction;
    
    printf("Enter Numbers:");
    scanf("%d%d",&a,&b);
    
    substraction=a-b;
    printf("\n substraction is %d",substraction);
}